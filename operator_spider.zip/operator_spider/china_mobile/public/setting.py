class MysqlCfg(object):
    host='192.168.10.40'
    user='admin'
    passwd='admin@123'
    db='spider'
    charset='utf8'


